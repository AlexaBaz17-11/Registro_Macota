﻿namespace Registro_Macota
{
    partial class Form1Registro_Macota
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1Registro_Macota));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonRegistrarDueño = new System.Windows.Forms.Button();
            this.textBoxTeléfonoDueño = new System.Windows.Forms.TextBox();
            this.textBoxDirecciónDueño = new System.Windows.Forms.TextBox();
            this.textBoxNombreDueño = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxDueñoMascota = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonRegistrarMascota = new System.Windows.Forms.Button();
            this.textBoxRazaMascota = new System.Windows.Forms.TextBox();
            this.textBoxEdadMascota = new System.Windows.Forms.TextBox();
            this.textBoxNombreMascota = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.buttonBuscarMascota = new System.Windows.Forms.Button();
            this.textBoxBuscarMascota = new System.Windows.Forms.TextBox();
            this.listBoxRegistroMascota = new System.Windows.Forms.ListBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(350, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(320, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "HOGAR ANIMAL";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(713, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 113);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Salmon;
            this.groupBox1.Controls.Add(this.buttonRegistrarDueño);
            this.groupBox1.Controls.Add(this.textBoxTeléfonoDueño);
            this.groupBox1.Controls.Add(this.textBoxDirecciónDueño);
            this.groupBox1.Controls.Add(this.textBoxNombreDueño);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("MV Boli", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(252, 254);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DUEÑO";
            // 
            // buttonRegistrarDueño
            // 
            this.buttonRegistrarDueño.Location = new System.Drawing.Point(88, 199);
            this.buttonRegistrarDueño.Name = "buttonRegistrarDueño";
            this.buttonRegistrarDueño.Size = new System.Drawing.Size(158, 34);
            this.buttonRegistrarDueño.TabIndex = 3;
            this.buttonRegistrarDueño.Text = "REGISTRAR";
            this.buttonRegistrarDueño.UseVisualStyleBackColor = true;
            this.buttonRegistrarDueño.Click += new System.EventHandler(this.buttonRegistrarDueño_Click);
            // 
            // textBoxTeléfonoDueño
            // 
            this.textBoxTeléfonoDueño.Location = new System.Drawing.Point(118, 142);
            this.textBoxTeléfonoDueño.Multiline = true;
            this.textBoxTeléfonoDueño.Name = "textBoxTeléfonoDueño";
            this.textBoxTeléfonoDueño.Size = new System.Drawing.Size(99, 31);
            this.textBoxTeléfonoDueño.TabIndex = 5;
            // 
            // textBoxDirecciónDueño
            // 
            this.textBoxDirecciónDueño.Location = new System.Drawing.Point(118, 88);
            this.textBoxDirecciónDueño.Multiline = true;
            this.textBoxDirecciónDueño.Name = "textBoxDirecciónDueño";
            this.textBoxDirecciónDueño.Size = new System.Drawing.Size(99, 26);
            this.textBoxDirecciónDueño.TabIndex = 4;
            // 
            // textBoxNombreDueño
            // 
            this.textBoxNombreDueño.Location = new System.Drawing.Point(118, 39);
            this.textBoxNombreDueño.Multiline = true;
            this.textBoxNombreDueño.Name = "textBoxNombreDueño";
            this.textBoxNombreDueño.Size = new System.Drawing.Size(99, 30);
            this.textBoxNombreDueño.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 26);
            this.label4.TabIndex = 2;
            this.label4.Text = "Teléfono";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 26);
            this.label3.TabIndex = 1;
            this.label3.Text = "Dirección";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nombre";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Salmon;
            this.groupBox2.Controls.Add(this.comboBoxDueñoMascota);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.buttonRegistrarMascota);
            this.groupBox2.Controls.Add(this.textBoxRazaMascota);
            this.groupBox2.Controls.Add(this.textBoxEdadMascota);
            this.groupBox2.Controls.Add(this.textBoxNombreMascota);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Font = new System.Drawing.Font("MV Boli", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(627, 206);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(262, 289);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MASCOTA";
            // 
            // comboBoxDueñoMascota
            // 
            this.comboBoxDueñoMascota.FormattingEnabled = true;
            this.comboBoxDueñoMascota.Location = new System.Drawing.Point(114, 150);
            this.comboBoxDueñoMascota.Name = "comboBoxDueñoMascota";
            this.comboBoxDueñoMascota.Size = new System.Drawing.Size(101, 34);
            this.comboBoxDueñoMascota.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 26);
            this.label8.TabIndex = 6;
            this.label8.Text = "Dueño";
            // 
            // buttonRegistrarMascota
            // 
            this.buttonRegistrarMascota.Location = new System.Drawing.Point(98, 215);
            this.buttonRegistrarMascota.Name = "buttonRegistrarMascota";
            this.buttonRegistrarMascota.Size = new System.Drawing.Size(158, 34);
            this.buttonRegistrarMascota.TabIndex = 3;
            this.buttonRegistrarMascota.Text = "REGISTRAR";
            this.buttonRegistrarMascota.UseVisualStyleBackColor = true;
            this.buttonRegistrarMascota.Click += new System.EventHandler(this.buttonRegistrarMascota_Click);
            // 
            // textBoxRazaMascota
            // 
            this.textBoxRazaMascota.Location = new System.Drawing.Point(114, 113);
            this.textBoxRazaMascota.Multiline = true;
            this.textBoxRazaMascota.Name = "textBoxRazaMascota";
            this.textBoxRazaMascota.Size = new System.Drawing.Size(101, 26);
            this.textBoxRazaMascota.TabIndex = 5;
            // 
            // textBoxEdadMascota
            // 
            this.textBoxEdadMascota.Location = new System.Drawing.Point(114, 78);
            this.textBoxEdadMascota.Multiline = true;
            this.textBoxEdadMascota.Name = "textBoxEdadMascota";
            this.textBoxEdadMascota.Size = new System.Drawing.Size(101, 29);
            this.textBoxEdadMascota.TabIndex = 4;
            // 
            // textBoxNombreMascota
            // 
            this.textBoxNombreMascota.Location = new System.Drawing.Point(114, 45);
            this.textBoxNombreMascota.Multiline = true;
            this.textBoxNombreMascota.Name = "textBoxNombreMascota";
            this.textBoxNombreMascota.Size = new System.Drawing.Size(101, 27);
            this.textBoxNombreMascota.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 26);
            this.label5.TabIndex = 2;
            this.label5.Text = "Raza";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 26);
            this.label6.TabIndex = 1;
            this.label6.Text = "Edad";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 26);
            this.label7.TabIndex = 0;
            this.label7.Text = "Nombre";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.MistyRose;
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.listBoxRegistroMascota);
            this.groupBox3.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(303, 144);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(293, 311);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Dueño de Mascota Registrada";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Gray;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(176, 34);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(92, 79);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Salmon;
            this.groupBox4.Controls.Add(this.buttonBuscarMascota);
            this.groupBox4.Controls.Add(this.textBoxBuscarMascota);
            this.groupBox4.Font = new System.Drawing.Font("MS UI Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(31, 205);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(237, 85);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Ingrese Nombre de la Mascota";
            // 
            // buttonBuscarMascota
            // 
            this.buttonBuscarMascota.Location = new System.Drawing.Point(122, 39);
            this.buttonBuscarMascota.Name = "buttonBuscarMascota";
            this.buttonBuscarMascota.Size = new System.Drawing.Size(109, 31);
            this.buttonBuscarMascota.TabIndex = 3;
            this.buttonBuscarMascota.Text = "BUSCAR";
            this.buttonBuscarMascota.UseVisualStyleBackColor = true;
            this.buttonBuscarMascota.Click += new System.EventHandler(this.buttonBuscarMascota_Click);
            // 
            // textBoxBuscarMascota
            // 
            this.textBoxBuscarMascota.Location = new System.Drawing.Point(6, 45);
            this.textBoxBuscarMascota.Name = "textBoxBuscarMascota";
            this.textBoxBuscarMascota.Size = new System.Drawing.Size(93, 25);
            this.textBoxBuscarMascota.TabIndex = 3;
            // 
            // listBoxRegistroMascota
            // 
            this.listBoxRegistroMascota.FormattingEnabled = true;
            this.listBoxRegistroMascota.ItemHeight = 21;
            this.listBoxRegistroMascota.Location = new System.Drawing.Point(54, 41);
            this.listBoxRegistroMascota.Name = "listBoxRegistroMascota";
            this.listBoxRegistroMascota.Size = new System.Drawing.Size(177, 130);
            this.listBoxRegistroMascota.TabIndex = 0;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(140, 329);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(136, 166);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(34, 305);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(129, 165);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // Form1Registro_Macota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(901, 520);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1Registro_Macota";
            this.Text = "Registro_Mascota";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonRegistrarDueño;
        private System.Windows.Forms.TextBox textBoxTeléfonoDueño;
        private System.Windows.Forms.TextBox textBoxDirecciónDueño;
        private System.Windows.Forms.TextBox textBoxNombreDueño;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxDueñoMascota;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button buttonRegistrarMascota;
        private System.Windows.Forms.TextBox textBoxRazaMascota;
        private System.Windows.Forms.TextBox textBoxEdadMascota;
        private System.Windows.Forms.TextBox textBoxNombreMascota;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button buttonBuscarMascota;
        private System.Windows.Forms.TextBox textBoxBuscarMascota;
        private System.Windows.Forms.ListBox listBoxRegistroMascota;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}

